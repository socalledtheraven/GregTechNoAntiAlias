---
name: Question
about: Have question regarding this project?
title: "[Question] "
labels: 'type: question'
assignees: ''

---

_Feel free to ask any question regarding this project here._
_If you are in need of quick response Discord may be a better place. As we have quite big community there so you may get response immediately also it works as knowledge hive._
_If you are looking for wiki we current don't have one, there is only available in-game info through tooltips or JEI. But someone on Discord may know what you need._
_If you are looking for API documentation or CT documentation. There is wiki on GitHub which holds some information. For CT documentation there are few pages for GTCE on official CT wiki. Also we have Discord channel for this purpose._
