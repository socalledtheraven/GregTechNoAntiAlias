package gregtech.common.blocks.tileentity;

public class TileEntityCrusherBlade extends TileEntityBase {

    @Override
    public boolean hasFastRenderer() {
        return true;
    }


}
