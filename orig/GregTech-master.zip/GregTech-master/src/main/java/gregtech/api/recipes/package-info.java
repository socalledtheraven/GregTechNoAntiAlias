@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
package gregtech.api.recipes;

import gregtech.api.util.FieldsAreNonnullByDefault;
import mcp.MethodsReturnNonnullByDefault;