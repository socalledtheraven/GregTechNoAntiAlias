package gregtech.api.util;

public interface IDirtyNotifiable {
    void markAsDirty();
}
