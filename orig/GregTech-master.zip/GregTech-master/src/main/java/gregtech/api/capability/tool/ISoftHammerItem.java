package gregtech.api.capability.tool;

public interface ISoftHammerItem {

    boolean damageItem(int damage, boolean simulate);

}
