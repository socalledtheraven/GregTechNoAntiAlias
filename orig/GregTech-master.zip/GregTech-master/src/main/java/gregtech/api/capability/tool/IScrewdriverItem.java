package gregtech.api.capability.tool;

public interface IScrewdriverItem {

    boolean damageItem(int damage, boolean simulate);

}
