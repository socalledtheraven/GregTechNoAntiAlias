package gregtech.api.worldgen.shape;

public interface IBlockGeneratorAccess {

    boolean generateBlock(int x, int y, int z);

}
