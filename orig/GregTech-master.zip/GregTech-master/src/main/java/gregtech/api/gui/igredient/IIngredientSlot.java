package gregtech.api.gui.igredient;

public interface IIngredientSlot {

    Object getIngredientOverMouse(int mouseX, int mouseY);

}
