package gregtech.api.pipenet.block.simple;

public class EmptyNodeData {

    public static final EmptyNodeData INSTANCE = new EmptyNodeData();

    private EmptyNodeData() {}
}
