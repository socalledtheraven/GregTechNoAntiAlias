package gregtech.api.capability.tool;

public interface IWrenchItem {

    boolean damageItem(int damage, boolean simulate);

}
