package gregtech.api.worldgen.populator;

public interface IBlockModifierAccess {

    boolean setBlock(int x, int y, int z, int index);

}
