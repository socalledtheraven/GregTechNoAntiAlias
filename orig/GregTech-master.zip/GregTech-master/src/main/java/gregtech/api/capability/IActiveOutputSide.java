package gregtech.api.capability;

public interface IActiveOutputSide {

    boolean isAutoOutputItems();

    boolean isAutoOutputFluids();

    boolean isAllowInputFromOutputSide();
}
