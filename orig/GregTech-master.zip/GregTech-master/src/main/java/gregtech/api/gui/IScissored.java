package gregtech.api.gui;

import java.awt.Rectangle;

public interface IScissored {

    Rectangle getScissor();
}
