/**
 * Contains a slightly modified minecraft multiblock system
 * main tweaks are use of mutable block pos & world states,
 * to make this system suitable for often multiblock checking
 */
package gregtech.api.multiblock;