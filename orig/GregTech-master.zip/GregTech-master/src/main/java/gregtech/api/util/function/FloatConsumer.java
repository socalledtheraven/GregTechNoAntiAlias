package gregtech.api.util.function;

@FunctionalInterface
public interface FloatConsumer {

    void apply(float value);

}
