package gregtech.api.util;

public enum EnumValidationResult {
    VALID,
    INVALID,
    SKIP
}
