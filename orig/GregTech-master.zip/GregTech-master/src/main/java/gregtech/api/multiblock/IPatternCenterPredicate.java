package gregtech.api.multiblock;

import java.util.function.Predicate;

public interface IPatternCenterPredicate extends Predicate<BlockWorldState> {

}
