package gregtech.api.util.function;

@FunctionalInterface
public interface BooleanConsumer {

    void apply(boolean value);
}
