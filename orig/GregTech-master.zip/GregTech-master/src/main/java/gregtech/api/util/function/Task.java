package gregtech.api.util.function;

public interface Task {

    boolean run();

}
