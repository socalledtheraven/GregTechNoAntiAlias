package gregtech.api.items.metaitem.stats;

/**
 * Deprecated, use {@link IItemComponent} instead
 * Left for binary compatibility with addons
 */
@Deprecated
public interface IMetaItemStats {
}
