package gregtech.api.gui;

public interface EnableNotifiedWidget {

    void setEnabled(boolean isEnabled);

}
