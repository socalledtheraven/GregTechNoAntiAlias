package gregtech.api.pipenet.tile;

public enum AttachmentType {
    COVER,
    PIPE,
    MULTIPART
}
