package gregtech.api.items;


public enum OreDictNames {

    string,
    chestWood,
    chestEnder,

    craftingAnvil,
    craftingFurnace,
    craftingBook,

    craftingDiamondBlade,
    craftingDuctTape,
    craftingGrinder,
    craftingPiston,

    craftingIronFurnace,
    craftingLensBlack,
    craftingLensBlue,
    craftingLensBrown,
    craftingLensCyan,
    craftingLensGray,
    craftingLensGreen,
    craftingLensLightBlue,
    craftingLensLightGray,
    craftingLensLime,
    craftingLensMagenta,
    craftingLensOrange,
    craftingLensPink,
    craftingLensPurple,
    craftingLensRed,
    craftingLensWhite,
    craftingLensYellow
}